<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wp');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'D.@0e,RS`P12wz&Dhy0@&Mw%Mr8?<Ek<&D1<!.tnca{xZUitxhfD7a]g5eo75g&<');
define('SECURE_AUTH_KEY',  'R|rNLbk9RdHPM+|$$w@r)/cm-A{ROA% CvUfPA%y9J]_C2kVHkO{HJDmb0w+@;_7');
define('LOGGED_IN_KEY',    ' PKKGa.2orc*gWD@p&HpU6oeP$p^$<qPA{L2GYs8v.-&i6N?/{^b9yv?r4&7>+V;');
define('NONCE_KEY',        'a``8q(`_JkWPE|$S:@aJbG|3)^h^ylalO:/R7I(~~AZ0X0@SPy99- jTJdB`~#)H');
define('AUTH_SALT',        'i0u~;`;yCT-^i8mV:f:6X0~ZL:?o2b~PZib|f;8Q:0$//OTP(tVK1>w(eNZ&QTPc');
define('SECURE_AUTH_SALT', 'er{[ZnI%L!_,@CSkt$Upur^ D]]H1Scmppd|q_]i)sF*}x6qwXYt,w&WLw36Fs3a');
define('LOGGED_IN_SALT',   'D|&$L!6oO.vk+]R}HX>[o$?9@MsCO_k2`B#(p5yE:H9$Z`d!~=9[Tn>3]rb/M/>D');
define('NONCE_SALT',       'Cj9^za&&PnWw?f)C9?Dq:n>5%Jd;av8${$_a%&hvZBL603yiJczX7;<)z)<-Mixp');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
